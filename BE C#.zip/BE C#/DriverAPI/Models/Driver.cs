public class Driver
{
    public string driverId { get; set; }

    public string? driverFirstName { get; set; }

    public string? driverLastName { get; set; }
    public string? driverPhoneNumber { get; set; }

    public string? driverEmail { get; set; }
}
