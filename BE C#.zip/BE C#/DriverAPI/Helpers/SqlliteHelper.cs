// Data/SQLiteHelper.cs
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SQLite;
using Microsoft.Data.Sqlite;

public class SQLiteHelper
{
    private readonly string _connectionString;

    public SQLiteHelper(string connectionString)
    {
        _connectionString = connectionString;
    }

    public SqliteConnection OpenConnection()
    {
        var connection = new SqliteConnection(_connectionString);
        connection.Open();
        return connection;
    }
}
