public class NameHelper
{
    public static string AlphabetizeName(string? name)
    {
        if (name != null)
        {
            char[] nameArray = name.ToCharArray();
            Array.Sort(nameArray);
            return new string(nameArray);
        }
        else
        {
            return name;
        }

    }

    public static string generateRandomString()
    {
        const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        var random = new Random();
        return new string(Enumerable.Repeat(chars, 8)
            .Select(s => s[random.Next(s.Length)]).ToArray());
    }
}
