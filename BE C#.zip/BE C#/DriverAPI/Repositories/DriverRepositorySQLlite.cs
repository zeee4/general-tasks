using Microsoft.Data.Sqlite;
using Microsoft.Extensions.Logging;
using System;

public class DriverRepositorySQLite : IDriverRepository
{
    private readonly SQLiteHelper _sqliteHelper;
    private readonly ILogger<DriverRepositorySQLite> _logger;

    public DriverRepositorySQLite(SQLiteHelper sqliteHelper, ILogger<DriverRepositorySQLite> logger)
    {
        _sqliteHelper = sqliteHelper;
        _logger = logger;
    }

    public List<Driver> getAllDrivers()
    {
        try
        {
            _logger.LogInformation("Attempting to retrieve all drivers");
            var drivers = new List<Driver>();
            using (var connection = _sqliteHelper.OpenConnection())
            using (var command = new SqliteCommand("SELECT * FROM Driver", connection))
            using (var reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    var driver = new Driver
                    {
                        driverId = reader["driverId"].ToString(), // Explicitly convert string to string
                        driverFirstName = reader["driverFirstName"].ToString(),
                        driverLastName = reader["driverLastName"].ToString(),
                        driverEmail = reader["driverEmail"].ToString(),
                        driverPhoneNumber = reader["driverPhoneNumber"].ToString(),
                    };
                    drivers.Add(driver);
                }
            }
            _logger.LogInformation("Successfully retrieved all drivers");
            return drivers;
        }
        catch (Exception ex)
        {
            _logger.LogError($"Error occurred while retrieving all drivers: {ex.Message}");
            throw; // Re-throw the exception to propagate it
        }
    }

    public Driver getDriverById(string id)
    {
        try
        {
            _logger.LogInformation($"Attempting to retrieve driver with ID: {id}");
            using (var connection = _sqliteHelper.OpenConnection())
            using (var command = new SqliteCommand($"SELECT * FROM Driver WHERE Id = {id}", connection))
            {
                using (var reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        // Map data from the reader to a Driver object
                        var driver = new Driver
                        {
                            driverId = reader["driverId"].ToString(),
                            driverFirstName = reader["FirstName"].ToString(),
                            driverLastName = reader["LastName"].ToString(),
                            // Add more properties as needed
                        };

                        _logger.LogInformation($"Successfully retrieved driver with ID: {id}");
                        return driver;
                    }
                }
            }

            _logger.LogWarning($"Driver with ID {id} not found.");
            return null;
        }
        catch (Exception ex)
        {
            _logger.LogError($"Error occurred while retrieving driver with ID {id}: {ex.Message}");
            throw; // Re-throw the exception to propagate it
        }
    }

    public void addDriver(Driver driver)
    {
        try
        {
            _logger.LogInformation("Attempting to add a new driver");

            using (var connection = _sqliteHelper.OpenConnection())
            using (var command = new SqliteCommand($"INSERT INTO Driver (driverId, driverFirstName,driverLastName,driverEmail,driverPhoneNumber) VALUES ('{driver.driverId}','{driver.driverFirstName}', '{driver.driverLastName}','{driver.driverEmail}','{driver.driverPhoneNumber}')", connection))
            {
                command.ExecuteNonQuery();
            }

            _logger.LogInformation($"Successfully added new driver with ID: {driver.driverId}");
        }
        catch (Exception ex)
        {
            _logger.LogError($"Error occurred while adding a new driver: {ex.Message}");
            throw; // Re-throw the exception to propagate it
        }
    }

    public void updateDriver(string driverId, Driver driver)
    {
        try
        {
            _logger.LogInformation($"Attempting to update driver with ID: {driver.driverId}");

            using (var connection = _sqliteHelper.OpenConnection())
            using (var command = new SqliteCommand($"UPDATE Drivers SET FirstName = '{driver.driverFirstName}', LastName = '{driver.driverLastName}' WHERE Id = {driver.driverId}", connection))
            {
                command.ExecuteNonQuery();
            }

            _logger.LogInformation($"Successfully updated driver with ID: {driver.driverId}");
        }
        catch (Exception ex)
        {
            _logger.LogError($"Error occurred while updating driver with ID {driver.driverId}: {ex.Message}");
            throw; // Re-throw the exception to propagate it
        }
    }

    public void deleteDriver(string id)
    {
        try
        {
            _logger.LogInformation($"Attempting to delete driver with ID: {id}");

            using (var connection = _sqliteHelper.OpenConnection())
            using (var command = new SqliteCommand($"DELETE FROM Driver WHERE Id = {id}", connection))
            {
                command.ExecuteNonQuery();
            }

            _logger.LogInformation($"Successfully deleted driver with ID: {id}");
        }
        catch (Exception ex)
        {
            _logger.LogError($"Error occurred while deleting driver with ID {id}: {ex.Message}");
            throw; // Re-throw the exception to propagate it
        }
    }

    public void addRandomDrivers(List<Driver> drivers)
    {
        try
        {
            _logger.LogInformation($"Attempting to add {drivers.Count} random drivers");

            using (var connection = _sqliteHelper.OpenConnection())
            using (var transaction = connection.BeginTransaction())
            {
                try
                {
                    foreach (var driver in drivers)
                    {
                        using (var command = new SqliteCommand($"INSERT INTO Driver (driverId, driverFirstName, driverLastName) VALUES ('{driver.driverId}', '{driver.driverFirstName}', '{driver.driverLastName}')", connection, transaction))
                        {
                            command.ExecuteNonQuery();
                        }
                    }

                    transaction.Commit();
                    _logger.LogInformation($"Successfully added {drivers.Count} random drivers");
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    _logger.LogError($"Error occurred while adding random drivers: {ex.Message}");
                    throw;
                }
            }
        }
        catch (Exception ex)
        {
            _logger.LogError($"Error occurred while adding random drivers: {ex.Message}");
            throw;
        }
    }

}