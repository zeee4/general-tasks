using System.Collections.Generic;

public interface IDriverRepository
{
    List<Driver> getAllDrivers();
    Driver getDriverById(string id);
    void addDriver(Driver driver);
    void updateDriver(string driverId, Driver driver);
    void deleteDriver(string id);
    void addRandomDrivers(List<Driver> drivers);
}