
public class DriverService : IDriverService
{
    private readonly IDriverRepository _driversRepository;
    private readonly ILogger<DriverService> _logger;


    public DriverService(IDriverRepository driversRepository, ILogger<DriverService> logger)
    {
        _driversRepository = driversRepository;
        _logger = logger;

    }

    public void addDriver(Driver newDriver)
    {
        try
        {
            _logger.LogInformation("Attempting to add a new driver.");
            newDriver.driverId = Guid.NewGuid().ToString();
            _driversRepository.addDriver(newDriver);
            _logger.LogInformation($"Successfully added and alphabetized new driver with ID: {newDriver.driverId}");
        }
        catch (Exception ex)
        {
            _logger.LogError($"Error occurred while adding a new driver: {ex.Message}");
            throw; // Re-throw the exception to propagate it
        }
    }

    public void deleteDriver(string id)
    {
        try
        {
            _logger.LogInformation($"Attempting to delete driver with ID: {id}");
            _driversRepository.deleteDriver(id);
            _logger.LogInformation($"Successfully deleted driver with ID: {id}");
        }
        catch (Exception ex)
        {
            _logger.LogError($"Error occurred while deleting driver with ID {id}: {ex.Message}");
            throw; // Re-throw the exception to propagate it
        }
    }

    public List<Driver> getAllDrivers()
    {
        try
        {
            _logger.LogInformation($"Attempting to retrieve drivers");
            List<Driver> drivers = _driversRepository.getAllDrivers();
            foreach (var driver in drivers)
            {
                AlphabetizeDriverNames(driver);
            }

            _logger.LogInformation($"Successfully retrieved and alphabetized drivers");
            return drivers;
        }
        catch (Exception ex)
        {
            _logger.LogError($"Error occurred while retrieving drivers: {ex.Message}");
            throw; // Re-throw the exception to propagate it
        }

    }

    public Driver getDriverById(string id)
    {
        try
        {
            _logger.LogInformation($"Attempting to retrieve driver with ID: {id}");
            Driver driver = _driversRepository.getDriverById(id);
            if (driver == null)
            {
                _logger.LogWarning($"Driver with ID {id} not found.");
                return null;
            }
            AlphabetizeDriverNames(driver);
            _logger.LogInformation($"Successfully retrieved and alphabetized driver with ID: {id}");
            return driver;
        }
        catch (Exception ex)
        {
            _logger.LogError($"Error occurred while retrieving driver with ID {id}: {ex.Message}");
            throw; // Re-throw the exception to propagate it
        }
    }

    public void updateDriver(string id, Driver updatedDriver)
    {
        try
        {
            _logger.LogInformation($"Attempting to update driver with ID: {id}");
            _driversRepository.updateDriver(id, updatedDriver);
            AlphabetizeDriverNames(updatedDriver);
            _logger.LogInformation($"Successfully updated and alphabetized driver with ID: {id}");
        }
        catch (Exception ex)
        {
            _logger.LogError($"Error occurred while updating driver with ID {id}: {ex.Message}");
            throw; // Re-throw the exception to propagate it
        }
    }


    private void AlphabetizeDriverNames(Driver driver)
    {
        driver.driverFirstName = NameHelper.AlphabetizeName(driver.driverFirstName);
        driver.driverLastName = NameHelper.AlphabetizeName(driver.driverLastName);
    }

    public void addRandomDrivers(int count)
    {
        _logger.LogInformation($"Attempting to add random drivers");

        try
        {
            _driversRepository.addRandomDrivers(generateRandomDrivers(count));
        }
        catch (Exception ex)
        {
            _logger.LogError($"Error occurred while adding random drivers: {ex.Message}");
            throw;
        }
    }

    private List<Driver> generateRandomDrivers(int count)
    {
        var randomDrivers = new List<Driver>();

        for (int i = 0; i < count; i++)
        {
            var randomFirstName = NameHelper.generateRandomString();
            var randomLastName = NameHelper.generateRandomString();

            var driver = new Driver
            {
                driverId = Guid.NewGuid().ToString(),
                driverFirstName = randomFirstName,
                driverLastName = randomLastName,
            };

            randomDrivers.Add(driver);
        }

        return randomDrivers;
    }





}