public interface IDriverService
{
    List<Driver> getAllDrivers();
    Driver getDriverById(string id);
    void addDriver(Driver driver);
    void updateDriver(string id, Driver driver);
    void deleteDriver(string id);

    void addRandomDrivers(int count);

}