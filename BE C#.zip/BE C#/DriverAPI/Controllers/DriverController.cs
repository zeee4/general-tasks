using Microsoft.AspNetCore.Mvc;

namespace DriverAPI.Controllers;
[ApiController]
[Route("api/drivers")]
public class DriversController : ControllerBase
{
    private readonly IDriverService _driverService;

    public DriversController(IDriverService driverService)
    {
        _driverService = driverService;
    }

    [HttpGet]
    public ActionResult<List<Driver>> GetAllDrivers()
    {
        var drivers = _driverService.getAllDrivers();
        return Ok(drivers);

    }

    [HttpGet("{id}")]
    public ActionResult<Driver> GetDriverById(string id)
    {
        var driver = _driverService.getDriverById(id);
        if (driver == null)
        {
            return NotFound();
        }
        return Ok(driver);
    }

    [HttpPost]
    public ActionResult AddDriver(Driver driver)
    {
        _driverService.addDriver(driver);
        return CreatedAtAction(nameof(GetDriverById), new { id = driver.driverId }, driver);
    }

    [HttpPut("{id}")]
    public ActionResult UpdateDriver(string id, Driver driver)
    {
        if (id != driver.driverId)
        {
            return BadRequest();
        }

        // _driversService.UpdateDriver(driver);
        return NoContent();
    }

    [HttpDelete("{id}")]
    public ActionResult DeleteDriver(string id)
    {
        // _driversService.DeleteDriver(id);
        return NoContent();
    }
}
