public class Startup
{
    public Startup(IConfiguration configuration)
    {
        Configuration = configuration;
    }

    public IConfiguration Configuration { get; }

    public void ConfigureServices(IServiceCollection services)
    {
        var connectionString = Configuration.GetConnectionString("DefaultConnection");
        if (connectionString != null)
        {
            services.AddSingleton(new SQLiteHelper(connectionString));
        }
        services.AddTransient<IDriverService, DriverService>();
        services.AddSingleton<IDriverRepository, DriverRepositorySQLite>();

        services.AddLogging(builder =>
        {
            builder.AddConsole();
        });

        services.AddMvc();


    }

    public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
    {
        if (env.IsDevelopment())
        {
            app.UseDeveloperExceptionPage();
        }
        else
        {
            // Add production error handling middleware here
            app.UseExceptionHandler("/Home/Error");
            app.UseHsts();
        }

        // Enable static files (e.g., HTML, CSS, JS)
        app.UseStaticFiles();

        // Enable routing
        app.UseRouting();

        // Enable authorization (if needed)
        app.UseAuthorization();

        // Enable endpoint routing and MapControllers
        app.UseEndpoints(endpoints =>
        {
            endpoints.MapControllers(); // Map controllers using endpoint routing
        });
    }
}
