using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;

public class Program
{
    public static void Main(string[] args)
    {
        // Seed data before building the host to implment the functionality of adding 10 random drivers
        SeedData();
        CreateHostBuilder(args).Build().Run();

    }
    public static void SeedData()
    {
        var host = CreateHostBuilder(Array.Empty<string>()).Build();

        using (var scope = host.Services.CreateScope())
        {
            var serviceProvider = scope.ServiceProvider;

            // Retrieve IDriverService and invoke the seed method
            var driverService = serviceProvider.GetRequiredService<IDriverService>();
            driverService.addRandomDrivers(10);
        }
    }

    public static IHostBuilder CreateHostBuilder(string[] args) =>
        Host.CreateDefaultBuilder(args)
            .ConfigureWebHostDefaults(webBuilder =>
            {
                webBuilder.UseStartup<Startup>();
            });
}
